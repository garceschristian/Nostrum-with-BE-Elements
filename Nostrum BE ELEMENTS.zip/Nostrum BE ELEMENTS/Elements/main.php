<main>
    <div id="background1"><img alt src="assets/images/skyline-buildings-new-york-skyscrapers.jpg"></div>
    <div id="title">
      <h1>Sed ut perspiciatis unde omnis<br>iste natus error sit <br></h1>
      <h2>Nemo enim ipsam voluptatem<br>quia voluptas sit<br></h2></div>
    <div id="cellphone"><img alt src=assets/images/device_black.png></div>
    <button id="voluptas">Voluptatibus</button>
    <div id="three-div">
      <div id="first-div"><img alt src="assets/images/wifi.png"></div>
      <div id="second-div">Nam libero tempore, cum
        <br>soluta nobis est eligendi
        <br>optio cumque nihil impedit</div>
      <div id="third-div"><img alt src="assets/images/connect.png"></div>
      <div id="fourth-div">Nam libero tempore, cum
        <br>soluta nobis est eligendi
        <br>optio cumque nihil impedit</div>
      <div id="fifth-div"><img alt src="assets/images/message.png"></div>
      <div id="sixth-div">Nam libero tempore, cum
        <br>soluta nobis est eligendi
        <br>optio cumque nihil impedit</div>
    </div>
  </main>