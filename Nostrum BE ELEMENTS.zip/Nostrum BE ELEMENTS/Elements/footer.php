 <footer>
    <div id="cellphone1"><img alt src="assets/images/iphone7.png"></div>
    <div id="text1">At vero eos et accusamus et lusto odio</div>
    <div id="text2">Nam libero tempore, cum soluta nobis est eligendi optio
      <br>nihil impedit quo minus id quiod maxime placeat facere</div>
    <button id="vel_illum"> Vel illum qui</button>
    <div id="text3"> Ut enim ad minima veniam </div>
    <div id="phone"><img alt src="assets/images/phone.png"></div>
    <div id="text4_background"></div>
    <div id="wifi_logo_2"><img alt src="assets/images/wifi.png"></div>
    <div id="text4"> Nam libero tempore, cum
      <br>soluta nobis est eligendi</div>
    <div id="text5_background"></div>
    <div id="connect_logo_2"><img alt src="assets/images/connect.png"></div>
    <div id="text5"> Nam libero tempore, cum
      <br>soluta nobis est eligendi</div>
    <div id="text6_background"></div>
    <div id="text6"> Nam libero tempore, cum
      <br>soluta nobis est eligendi</div>
    <div id="message_logo_2"><img alt src="assets/images/message.png"></div>
    <button id="qui_ratione"> Qui ratione</button>
    <button id="iste_natus"> Iste natus</button>
    <div id="box_background"></div>
    
 <div class="container">
        <form id="form" action="/">
        
            <div class="input-control">
                <label for="username"></label>
                <input id="username" name="username" type="text" Placeholder = "Adispiscing">
                <div class="error"></div>
            </div>
           
            <div class="input-control">
                <label for="password"></label>
                <input id="password" name="password" type="password" Placeholder = "Ex ea commodi">
                <div class="error"></div>
            </div>
            
            <button type="submit">Vel illum qui</button>
        </form>
   </div>








  </footer>

</html>