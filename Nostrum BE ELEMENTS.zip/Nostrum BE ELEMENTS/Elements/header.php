<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Nostrum </title>
  <link rel="stylesheet" type="text/css" href="assets/css/nostrum.css">
  <script defer src= "assets/js/index.js"></script>
 </head>
<body>
  <header>
    <a href="#"><img src="assets/images/nostrum.png" alt="logo" id="logo"></a>
    <nav id="top-nav"> <span class="with-bar"><a href="#" >Lorem</a></span> <span class="with-bar"><a href="#" >Ipsum</a></span> <span class="with-bar"><a href="#" >Dolor</a></span> </nav>
    <button id="search-icon"><img alt src="assets/images/ICON_MAGNIFYING.png"></button>
    <input type="text" placeholder="Aperiam" id="search-box"> </header>